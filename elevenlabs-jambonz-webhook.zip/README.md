# ElevenLabs Jambonz Webhook

This webhook connects Jambonz phone calls to your ElevenLabs Conversational AI agent.

## Agent ID
Your ElevenLabs Agent: `agent_5001ke958d2qfngvsavg213h3nq1`

## Quick Deploy Options

### Option 1: Deploy to Render (Recommended - Completely Free)

1. Go to https://render.com and sign up (free)
2. Click "New +" → "Web Service"
3. Connect your GitHub account or use "Deploy from Git URL"
4. If using Git URL, first push this code to GitHub, or use the manual upload option
5. Configure:
   - **Name**: elevenlabs-jambonz
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free
6. Click "Create Web Service"
7. Wait for deployment (2-3 minutes)
8. Copy your webhook URL (will be like: `https://elevenlabs-jambonz.onrender.com/webhook`)

### Option 2: Deploy to Railway (Free)

1. Go to https://railway.app and sign up
2. Click "New Project" → "Deploy from GitHub repo"
3. Upload these files to a GitHub repo first
4. Select the repo
5. Railway will auto-detect Node.js and deploy
6. Get your webhook URL from the deployment

### Option 3: Deploy to Glitch (Easiest)

1. Go to https://glitch.com and sign up
2. Click "New Project" → "Import from GitHub"
3. Or click "New Project" → "glitch-hello-node" 
4. Delete the default files
5. Upload `server.js` and `package.json`
6. Glitch will auto-install and run
7. Click "Share" → Copy the live site URL
8. Your webhook URL will be: `https://YOUR-PROJECT-NAME.glitch.me/webhook`

### Option 4: Replit (Fast Setup)

1. Go to https://replit.com and sign up
2. Click "Create Repl"
3. Choose "Node.js" template
4. Name it "elevenlabs-jambonz"
5. Delete the default index.js
6. Upload `server.js` and `package.json`
7. Click "Run"
8. Copy the URL shown (will be like: `https://elevenlabs-jambonz.YOUR-USERNAME.repl.co/webhook`)

## What to Do After Deployment

1. Copy your webhook URL (e.g., `https://your-app.onrender.com/webhook`)
2. Go back to Jambonz
3. In the "Calling webhook" field, paste your webhook URL
4. In "Call status webhook", paste: `https://your-app.onrender.com/status`
5. Change "Speech synthesis vendor" to "elevenlabs"
6. Save the application
7. Assign it to your phone number (27838270149)
8. Test by calling your number!

## How It Works

When someone calls your Jambonz number:
1. Jambonz receives the call
2. Jambonz sends a request to your webhook
3. Your webhook returns JSON instructions
4. The instructions tell Jambonz to connect the call to your ElevenLabs agent
5. The caller talks to your ElevenLabs IVR agent!

## Testing

After deployment, visit your webhook URL in a browser (without `/webhook`).
You should see: "ElevenLabs Jambonz Webhook is running! Agent ID: agent_5001ke958d2qfngvsavg213h3nq1"

## Troubleshooting

- Make sure your webhook URL ends with `/webhook`
- Make sure it starts with `https://` (not `http://`)
- Check that your ElevenLabs API key is properly configured in Jambonz
- Check the logs in your hosting platform for errors
